create view V_USERS_ROLES as
  select `U`.`Username` AS `Username`, `R`.`RoleName` AS `RoleName`
  from ((`quirondb_test`.`USERS_ROLES` `UR` join `quirondb_test`.`USERS` `U` on ((`UR`.`UserID` =
                                                                                  `U`.`UserID`))) join `quirondb_test`.`ROLES` `R` on ((
    `UR`.`RoleID` = `R`.`RoleID`)));

