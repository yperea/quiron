create view V_USERS_ROLES as
  select `U`.`Username` AS `Username`, `R`.`RoleName` AS `RoleName`
  from ((`quirondb`.`USERS_ROLES` `UR` join `quirondb`.`USERS` `U` on ((`UR`.`UserID` =
                                                                        `U`.`UserID`))) join `quirondb`.`ROLES` `R` on ((
    `UR`.`RoleID` = `R`.`RoleID`)));

